# Relay — AI Data Automation Landing Page

A premium, responsive landing page for an AI-driven data automation
platform, built for the **Frontend Battle Phase 1: Next-Gen AI Platform
Speed Run** brief.

Live demo: _add your deployed URL here_
Stack: **Next.js 14 (App Router) · TypeScript · Tailwind CSS** — no UI or
animation component libraries.

---

## Running locally

```bash
npm install
npm run dev      # http://localhost:3000
```

Production build (also runs the type checker):

```bash
npm run build
npm run start
```

---

## How this satisfies the brief

### Feature 1 — Matrix-driven pricing & isolated currency switcher

All logic lives in [`lib/pricing-data.ts`](lib/pricing-data.ts):

- `PRICING_TIERS` — base **USD** monthly rate per tier.
- `ANNUAL_DISCOUNT_MULTIPLIER` — a single flat **20%** annual discount
  constant.
- `REGIONAL_MATRIX` — FX rate **and** a separate regional tariff load
  factor per currency (`USD` / `EUR` / `INR`).
- `computePrice(tier, billing, currency)` walks all three dimensions and
  returns a formatted price. **No price is ever hardcoded** in a
  component — every tier card calls this function.

**Re-render isolation** ([`lib/pricing-store.ts`](lib/pricing-store.ts),
[`components/pricing/PriceText.tsx`](components/pricing/PriceText.tsx)):
state lives in a small hand-rolled pub/sub store, *not* React state or
Context. `<PriceText>` is the only thing that subscribes to it, and on
every update it mutates its own `<span>`'s `textContent` directly inside
the subscription callback — completely outside React's render cycle.
`<CurrencySwitcher>` and `<BillingToggle>` only hold their *own* selected-
pill UI state and dispatch to the store; they never touch the pricing
cards. Net effect: toggling currency or billing produces **zero React
re-renders** above the individual price text nodes — verifiable in the
React DevTools Profiler (no commits fire outside the two control
components) or in Chrome's Performance panel (no layout/recalc cascade
beyond the changed `<span>`s).

The price `<span>` is still server-rendered with the default (USD /
monthly) value first, so it's a real, crawlable text node on first paint.

### Feature 2 — Bento-to-Accordion with state persistence

[`components/bento/BentoAccordion.tsx`](components/bento/BentoAccordion.tsx)
renders **both** the desktop bento grid and the mobile accordion at all
times; pure CSS (`hidden md:grid` / `md:hidden`) decides which is
visible, so the correct layout paints immediately with no client-side
flash. Both views read and write the same lifted `activeIndex` state —
a hover on desktop and the open panel on mobile are two views of one
number, so there's nothing to keep in sync.

**Context Lock Constraint:** a `matchMedia` listener watches the mobile
breakpoint. The instant it crosses into mobile range, whichever node
currently has hover/focus is promoted into `activeIndex` *before* the
accordion paints — so resizing mid-hover opens the matching panel
automatically. Re-widening the window restores the same node's bento
highlight.

Zero dependencies: the grid, the accordion panel open/close animation
(CSS `grid-template-rows` transition), and the hover/focus tracking are
all written from scratch with native CSS transitions — no Framer Motion,
Radix, Shadcn, or HeadlessUI anywhere in the dependency tree.

### Motion

All transitions use the timing contract from the brief, expressed as
Tailwind tokens in `tailwind.config.ts`:

| Use | Duration | Easing |
|---|---|---|
| Micro-interactions (hover/toggle) | 150–200ms (`duration-micro`) | `ease-out-micro` |
| Structural reflows (accordion, nav) | 300–400ms (`duration-reflow`) | `ease-inout-reflow` |

The hero's entry choreography (`app/globals.css` → `.entrance` /
`hero-in`) staggers five elements at 0/40/80/120/160ms with a 300ms
animation each, finishing at ~460ms — inside the 500ms orchestration
budget — and is implemented with a CSS `@keyframes` animation (no JS
timers), so it never blocks Time to Interactive. `prefers-reduced-motion`
is respected globally.

### SEO & semantic HTML

- Landmarks throughout: `<header>`, `<nav>`, `<main>`, `<section>`,
  `<article>`, `<footer>`; heading levels follow a single `h1 → h2 → h3`
  hierarchy.
- `app/layout.tsx` sets full metadata: title template, description,
  Open Graph, Twitter Card, canonical URL, robots directives, and
  JSON-LD (`SoftwareApplication`) structured data.
- `app/opengraph-image.tsx` and `app/icon.tsx` generate the social-share
  image and favicon at build time from the brand palette — no binary
  asset to keep in sync.
- `app/sitemap.ts` and `app/robots.ts` are real Next.js metadata routes.
- All icons are decorative by default (`aria-hidden`) unless given a
  `label`, in which case they get `role="img"` + `aria-label`.
- The FAQ accordion is a native `<details>/<summary>` — zero JavaScript,
  fully crawlable, keyboard-accessible by default.

### Assets

- **SVGs** — every icon in `asset_package/SVGs` is copied verbatim into
  `public/icons` and consumed through `components/ui/Icon.tsx`, which
  applies them as a CSS `mask` so they inherit `currentColor` instead of
  being forked/recolored by hand.
- **Fonts** — JetBrains Mono (headers, labels, prices, code-like UI) and
  Inter (body copy), self-hosted via `@fontsource` and wired up as CSS
  variables in `app/globals.css`, consumed through Tailwind's
  `font-mono` / `font-sans`. Self-hosting avoids any runtime dependency
  on Google's font CDN.
- **Color palette** — the six provided hex values are defined once as
  CSS variables and Tailwind color tokens (`oceanic-noir`,
  `nocturnal-expedition`, `forsythia`, `deep-saffron`, `arctic-powder`,
  `mystic-mint`) and used exclusively — no ad hoc hex codes elsewhere in
  the codebase.

---

## Project structure

```
app/                  Routes, root layout, metadata routes, global CSS
components/
  layout/             Header, Footer
  sections/           Hero, LogoStrip, FeatureBento, PricingMatrix,
                       Testimonials, FAQ, CTA
  pricing/             Feature 1 — PriceText, CurrencySwitcher, BillingToggle
  bento/               Feature 2 — BentoAccordion
  ui/                  Icon, SignalPulse
lib/                   pricing-data, pricing-store, bento-data, site-config
public/icons/          Provided SVG pack
```

## Deploying

Any platform that runs a standard Next.js build works out of the box —
**Vercel** (zero-config) or **Netlify** (`@netlify/plugin-nextjs`) are the
fastest paths. Set `NEXT_PUBLIC_SITE_URL` to your deployed URL so the
canonical link, sitemap, and OG image use the right domain.

> GitHub Pages can only serve static files. To target it, add
> `output: "export"` to `next.config.mjs` and run `next build`, then
> publish the generated `out/` directory — note this drops server-only
> features, which this project doesn't otherwise rely on.
