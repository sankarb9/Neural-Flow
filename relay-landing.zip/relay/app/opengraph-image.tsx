import { ImageResponse } from "next/og";
import { siteConfig } from "@/lib/site-config";

export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          background: "#172B36",
          padding: "72px",
          fontFamily: "sans-serif",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div
            style={{
              width: 16,
              height: 16,
              borderRadius: "50%",
              background: "#FFC801",
              display: "flex",
            }}
          />
          <span style={{ color: "#F1F6F4", fontSize: 28, fontWeight: 700, letterSpacing: -0.5 }}>
            relay
          </span>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
          <span
            style={{
              color: "#F1F6F4",
              fontSize: 64,
              fontWeight: 700,
              lineHeight: 1.1,
              maxWidth: 920,
            }}
          >
            Automate the data your AI agents depend on.
          </span>
          <span style={{ color: "rgba(241,246,244,0.6)", fontSize: 26, maxWidth: 760 }}>
            {siteConfig.description}
          </span>
        </div>

        <div style={{ display: "flex", gap: 40 }}>
          {[
            ["12ms", "Median latency"],
            ["99.98%", "Uptime"],
            ["4.2M", "Events / day"],
          ].map(([value, label]) => (
            <div key={label} style={{ display: "flex", flexDirection: "column" }}>
              <span style={{ color: "#FF9932", fontSize: 32, fontWeight: 700 }}>{value}</span>
              <span style={{ color: "rgba(241,246,244,0.5)", fontSize: 18 }}>{label}</span>
            </div>
          ))}
        </div>
      </div>
    ),
    { ...size }
  );
}
