import { Icon } from "@/components/ui/Icon";
import { SignalPulse } from "@/components/ui/SignalPulse";

const STATS = [
  { value: "12ms", label: "Median pipeline latency" },
  { value: "99.98%", label: "Platform uptime" },
  { value: "4.2M", label: "Events routed / day" },
];

export function Hero() {
  return (
    <section
      id="top"
      className="relative overflow-hidden bg-oceanic-noir px-6 pt-16 pb-20 sm:px-10 sm:pt-20 lg:px-16"
    >
      <SignalPulse className="pointer-events-none absolute inset-x-0 top-1/2 h-24 w-full -translate-y-1/2 text-forsythia/40" />

      <div className="relative mx-auto grid max-w-6xl gap-16 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
        <div>
          <p
            className="entrance font-mono text-xs uppercase tracking-[0.25em] text-forsythia"
            style={{ animationDelay: "0ms" }}
          >
            AI data automation
          </p>

          <h1
            className="entrance mt-5 text-balance font-mono text-4xl font-medium leading-[1.05] tracking-tight text-arctic-powder sm:text-5xl lg:text-6xl"
            style={{ animationDelay: "40ms" }}
          >
            Automate the data your AI agents depend on.
          </h1>

          <p
            className="entrance mt-6 max-w-lg text-balance text-base leading-relaxed text-arctic-powder/65 sm:text-lg"
            style={{ animationDelay: "80ms" }}
          >
            Relay connects every source system into one automated pipeline
            layer, so your agents act on data that&apos;s always current,
            never duplicated, and fully auditable.
          </p>

          <div
            className="entrance mt-9 flex flex-wrap items-center gap-4"
            style={{ animationDelay: "120ms" }}
          >
            <a
              href="#contact"
              className="rounded-full bg-forsythia px-6 py-3.5 font-mono text-xs uppercase tracking-wide text-oceanic-noir transition-colors duration-micro ease-out-micro hover:bg-deep-saffron"
            >
              Start building
            </a>
            <a
              href="#platform"
              className="inline-flex items-center gap-2 rounded-full border border-arctic-powder/20 px-6 py-3.5 font-mono text-xs uppercase tracking-wide text-arctic-powder transition-colors duration-micro ease-out-micro hover:border-arctic-powder/50"
            >
              See the platform
              <Icon name="chevron-right" className="h-3.5 w-3.5" />
            </a>
          </div>

          <dl
            className="entrance mt-14 grid grid-cols-3 gap-6 border-t border-arctic-powder/10 pt-8"
            style={{ animationDelay: "160ms" }}
          >
            {STATS.map((stat) => (
              <div key={stat.label}>
                <dt className="sr-only">{stat.label}</dt>
                <dd className="font-mono text-2xl font-medium text-arctic-powder sm:text-3xl">
                  {stat.value}
                </dd>
                <p className="mt-1 text-xs leading-snug text-arctic-powder/50">{stat.label}</p>
              </div>
            ))}
          </dl>
        </div>

        <div
          className="entrance relative"
          style={{ animationDelay: "120ms" }}
          aria-hidden
        >
          <div className="rounded-3xl border border-arctic-powder/10 bg-nocturnal-expedition/40 p-6 shadow-2xl shadow-oceanic-noir/40 backdrop-blur">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs uppercase tracking-wide text-arctic-powder/50">
                Pipeline / orders-sync
              </span>
              <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wide text-deep-saffron">
                <span className="h-1.5 w-1.5 animate-fade-in rounded-full bg-deep-saffron" />
                Live
              </span>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3">
              <DashboardTile icon="cog-8-tooth" label="Active nodes" value="38" />
              <DashboardTile icon="chart-pie" label="Schema coverage" value="100%" />
              <DashboardTile icon="cube-16-solid" label="Sources synced" value="14" />
              <DashboardTile icon="arrow-trending-up" label="Throughput" value="+18%" />
            </div>

            <div className="mt-6 rounded-2xl bg-oceanic-noir/60 p-4">
              <div className="flex items-center justify-between font-mono text-[11px] text-arctic-powder/50">
                <span>Sync depth</span>
                <span>82%</span>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-arctic-powder/10">
                <div className="h-full w-[82%] rounded-full bg-gradient-to-r from-forsythia to-deep-saffron" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function DashboardTile({
  icon,
  label,
  value,
}: {
  icon: Parameters<typeof Icon>[0]["name"];
  label: string;
  value: string;
}) {
  return (
    <div className="rounded-2xl border border-arctic-powder/10 bg-oceanic-noir/40 p-4">
      <Icon name={icon} className="h-4 w-4 text-forsythia" />
      <p className="mt-3 font-mono text-lg font-medium text-arctic-powder">{value}</p>
      <p className="mt-0.5 text-[11px] text-arctic-powder/50">{label}</p>
    </div>
  );
}
