export function CTA() {
  return (
    <section
      id="contact"
      aria-labelledby="cta-heading"
      className="bg-oceanic-noir px-6 py-24 sm:px-10 lg:px-16"
    >
      <div className="mx-auto flex max-w-4xl flex-col items-center gap-6 text-center">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-forsythia">
          Get started
        </p>
        <h2
          id="cta-heading"
          className="text-balance font-mono text-3xl font-medium tracking-tight text-arctic-powder sm:text-4xl"
        >
          Put your first pipeline live this afternoon.
        </h2>
        <p className="max-w-lg text-balance text-base text-arctic-powder/65">
          Connect a source, pick a tier, and watch the data move. No
          procurement call required to start.
        </p>
        <div className="mt-4 flex flex-wrap items-center justify-center gap-4">
          <a
            href="#pricing"
            className="rounded-full bg-forsythia px-6 py-3.5 font-mono text-xs uppercase tracking-wide text-oceanic-noir transition-colors duration-micro ease-out-micro hover:bg-deep-saffron"
          >
            View pricing
          </a>
          <a
            href="mailto:hello@relay.example"
            className="rounded-full border border-arctic-powder/20 px-6 py-3.5 font-mono text-xs uppercase tracking-wide text-arctic-powder transition-colors duration-micro ease-out-micro hover:border-arctic-powder/50"
          >
            Talk to sales
          </a>
        </div>
      </div>
    </section>
  );
}
