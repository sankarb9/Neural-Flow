import { PRICING_TIERS } from "@/lib/pricing-data";
import { BillingToggle } from "@/components/pricing/BillingToggle";
import { CurrencySwitcher } from "@/components/pricing/CurrencySwitcher";
import { PriceText } from "@/components/pricing/PriceText";
import { Icon } from "@/components/ui/Icon";

export function PricingMatrix() {
  return (
    <section
      id="pricing"
      aria-labelledby="pricing-heading"
      className="border-t border-mystic-mint bg-arctic-powder px-6 py-24 sm:px-10 lg:px-16"
    >
      <div className="mx-auto max-w-6xl">
        <header className="flex flex-col gap-6 text-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-deep-saffron">
            Pricing
          </p>
          <h2
            id="pricing-heading"
            className="text-balance font-mono text-3xl font-medium tracking-tight text-oceanic-noir sm:text-4xl"
          >
            One rate card. Every region.
          </h2>
          <p className="mx-auto max-w-xl text-balance text-base text-oceanic-noir/70">
            Prices recalculate live from a single configuration matrix — base
            rate, billing cycle, and regional tariff — never a hardcoded
            number on the page.
          </p>
        </header>

        <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row sm:justify-center sm:gap-6">
          <CurrencySwitcher />
          <BillingToggle />
        </div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {PRICING_TIERS.map((tier) => (
            <article
              key={tier.id}
              className={`flex flex-col rounded-2xl border p-8 transition-shadow duration-micro ease-out-micro ${
                tier.highlighted
                  ? "border-oceanic-noir bg-oceanic-noir text-arctic-powder shadow-xl shadow-oceanic-noir/10"
                  : "border-mystic-mint bg-white text-oceanic-noir hover:shadow-lg hover:shadow-nocturnal-expedition/5"
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <h3 className="font-mono text-xl font-medium">{tier.name}</h3>
                {tier.highlighted ? (
                  <span className="rounded-full bg-forsythia px-3 py-1 font-mono text-[10px] uppercase tracking-wide text-oceanic-noir">
                    Most popular
                  </span>
                ) : null}
              </div>
              <p
                className={`mt-1 font-mono text-xs uppercase tracking-wide ${
                  tier.highlighted ? "text-arctic-powder/60" : "text-oceanic-noir/50"
                }`}
              >
                {tier.eyebrow}
              </p>

              <div className="mt-6 flex items-baseline gap-2">
                <PriceText
                  tier={tier}
                  className="font-mono text-4xl font-medium tabular-nums"
                />
                <span
                  className={`text-sm ${
                    tier.highlighted ? "text-arctic-powder/60" : "text-oceanic-noir/50"
                  }`}
                >
                  / month
                </span>
              </div>

              <p
                className={`mt-4 text-sm leading-relaxed ${
                  tier.highlighted ? "text-arctic-powder/80" : "text-oceanic-noir/70"
                }`}
              >
                {tier.description}
              </p>

              <ul className="mt-6 flex flex-1 flex-col gap-3">
                {tier.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2.5 text-sm">
                    <Icon
                      name="chevron-right"
                      className={`mt-0.5 h-4 w-4 shrink-0 ${
                        tier.highlighted ? "text-forsythia" : "text-deep-saffron"
                      }`}
                    />
                    <span className={tier.highlighted ? "text-arctic-powder/90" : "text-oceanic-noir/80"}>
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              <a
                href="#contact"
                className={`mt-8 inline-flex items-center justify-center rounded-full px-5 py-3 font-mono text-xs uppercase tracking-wide transition-colors duration-micro ease-out-micro ${
                  tier.highlighted
                    ? "bg-forsythia text-oceanic-noir hover:bg-deep-saffron"
                    : "bg-oceanic-noir text-arctic-powder hover:bg-nocturnal-expedition"
                }`}
              >
                Start with {tier.name}
              </a>
            </article>
          ))}
        </div>

        <p className="mt-8 text-center text-xs text-oceanic-noir/50">
          All prices shown are per workspace, per month, and include a flat
          regional infrastructure tariff. Annual plans bill yearly at a 20%
          discount.
        </p>
      </div>
    </section>
  );
}
