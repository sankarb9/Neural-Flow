const COMPANIES = [
  "Northwind Analytics",
  "Halcyon Labs",
  "Verge Systems",
  "Ironclad Freight",
  "Quanta Retail",
  "Fathom Health",
];

export function LogoStrip() {
  return (
    <section
      aria-label="Companies using Relay"
      className="border-b border-mystic-mint bg-arctic-powder px-6 py-12 sm:px-10 lg:px-16"
    >
      <div className="mx-auto max-w-6xl">
        <p className="text-center font-mono text-xs uppercase tracking-[0.2em] text-oceanic-noir/40">
          Trusted by data teams at
        </p>
        <ul className="mt-8 flex flex-wrap items-center justify-center gap-x-12 gap-y-6">
          {COMPANIES.map((company) => (
            <li
              key={company}
              className="font-mono text-sm tracking-tight text-oceanic-noir/45 transition-colors duration-micro ease-out-micro hover:text-oceanic-noir/80"
            >
              {company}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
