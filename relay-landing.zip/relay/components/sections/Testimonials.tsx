const TESTIMONIALS = [
  {
    quote:
      "We replaced four cron jobs and a Slack alert no one trusted with one Relay pipeline. The first week it caught a schema change before it hit production.",
    name: "Priya Raman",
    role: "Head of Data Platform, Northwind Analytics",
  },
  {
    quote:
      "The regional pricing actually matches how our finance team buys software. No spreadsheet conversions, no surprise invoice in a currency we don't budget in.",
    name: "Owen Castellan",
    role: "VP Engineering, Verge Systems",
  },
  {
    quote:
      "Our on-call rotation stopped dreading the data layer. Adaptive routing alone cut our incident count in half within a quarter.",
    name: "Mei Lin Foster",
    role: "Staff SRE, Fathom Health",
  },
];

export function Testimonials() {
  return (
    <section
      id="customers"
      aria-labelledby="customers-heading"
      className="bg-mystic-mint/40 px-6 py-24 sm:px-10 lg:px-16"
    >
      <div className="mx-auto max-w-6xl">
        <header className="flex flex-col gap-6 text-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-deep-saffron">
            Customers
          </p>
          <h2
            id="customers-heading"
            className="text-balance font-mono text-3xl font-medium tracking-tight text-oceanic-noir sm:text-4xl"
          >
            Teams running on Relay
          </h2>
        </header>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {TESTIMONIALS.map((testimonial) => (
            <figure
              key={testimonial.name}
              className="flex flex-col justify-between rounded-2xl border border-mystic-mint bg-white p-7"
            >
              <blockquote className="text-balance text-sm leading-relaxed text-oceanic-noir/80">
                &ldquo;{testimonial.quote}&rdquo;
              </blockquote>
              <figcaption className="mt-6 border-t border-mystic-mint pt-4">
                <p className="font-mono text-sm font-medium text-oceanic-noir">
                  {testimonial.name}
                </p>
                <p className="mt-0.5 text-xs text-oceanic-noir/50">{testimonial.role}</p>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
