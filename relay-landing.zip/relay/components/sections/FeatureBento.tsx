import { BentoAccordion } from "@/components/bento/BentoAccordion";

export function FeatureBento() {
  return (
    <section
      id="platform"
      aria-labelledby="platform-heading"
      className="bg-oceanic-noir px-6 py-24 sm:px-10 lg:px-16"
    >
      <div className="mx-auto max-w-6xl">
        <header className="flex flex-col gap-6 text-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-forsythia">
            Platform
          </p>
          <h2
            id="platform-heading"
            className="text-balance font-mono text-3xl font-medium tracking-tight text-arctic-powder sm:text-4xl"
          >
            Built for how data actually moves
          </h2>
          <p className="mx-auto max-w-xl text-balance text-base text-arctic-powder/65">
            Six primitives, one runtime. On a wide screen they sit in a single
            grid you can scan at a glance; on a phone they collapse into a
            list you can work through one at a time.
          </p>
        </header>

        <div className="mt-14">
          <BentoAccordion />
        </div>
      </div>
    </section>
  );
}
