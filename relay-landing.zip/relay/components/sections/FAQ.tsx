import { Icon } from "@/components/ui/Icon";

const FAQS = [
  {
    question: "What counts as an automated pipeline?",
    answer:
      "Any scheduled or event-triggered job that moves or transforms data between two systems — a warehouse sync, a webhook relay, an enrichment step before it reaches an AI agent.",
  },
  {
    question: "How does the currency switcher decide a price?",
    answer:
      "Every price on this page is computed from one configuration matrix: a base USD rate per tier, a flat 20% multiplier for annual billing, and a regional tariff factor per currency. Nothing is hardcoded per currency.",
  },
  {
    question: "Can I self-host the runtime?",
    answer:
      "Mainline plans include a private deployment region. Signal and Relay plans run on our shared multi-tenant infrastructure with workspace-level isolation.",
  },
  {
    question: "Is there a free trial?",
    answer:
      "Yes — every plan starts with a 14-day trial, no card required. You can invite your team and connect a real source system before deciding on a tier.",
  },
  {
    question: "What happens if I switch billing cycles mid-month?",
    answer:
      "Switching to annual immediately applies the 20% discount and prorates your remaining monthly balance as credit toward the new term.",
  },
];

export function FAQ() {
  return (
    <section
      id="faq"
      aria-labelledby="faq-heading"
      className="bg-arctic-powder px-6 py-24 sm:px-10 lg:px-16"
    >
      <div className="mx-auto max-w-3xl">
        <header className="flex flex-col gap-6 text-center">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-deep-saffron">
            FAQ
          </p>
          <h2
            id="faq-heading"
            className="text-balance font-mono text-3xl font-medium tracking-tight text-oceanic-noir sm:text-4xl"
          >
            Common questions
          </h2>
        </header>

        <div className="mt-12 flex flex-col gap-3">
          {FAQS.map((faq) => (
            <details
              key={faq.question}
              className="group rounded-2xl border border-mystic-mint bg-white px-6 py-2 open:border-oceanic-noir/20"
            >
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-4 font-mono text-sm font-medium text-oceanic-noir marker:content-none">
                {faq.question}
                <Icon
                  name="chevron-down"
                  className="h-4 w-4 shrink-0 text-oceanic-noir/50 transition-transform duration-micro ease-out-micro group-open:rotate-180 group-open:text-deep-saffron"
                />
              </summary>
              <p className="pb-5 text-sm leading-relaxed text-oceanic-noir/70">{faq.answer}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
