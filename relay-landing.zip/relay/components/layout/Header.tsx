"use client";

import { useState } from "react";
import { Icon } from "@/components/ui/Icon";

const NAV_LINKS = [
  { href: "#platform", label: "Platform" },
  { href: "#pricing", label: "Pricing" },
  { href: "#customers", label: "Customers" },
  { href: "#faq", label: "FAQ" },
];

export function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-mystic-mint/60 bg-arctic-powder/90 backdrop-blur">
      <nav
        aria-label="Primary"
        className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4 sm:px-10 lg:px-16"
      >
        <a href="#top" className="font-mono text-lg font-semibold tracking-tight text-oceanic-noir">
          relay<span className="text-forsythia">.</span>
        </a>

        <ul className="hidden items-center gap-8 md:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="font-mono text-xs uppercase tracking-wide text-oceanic-noir/70 transition-colors duration-micro ease-out-micro hover:text-oceanic-noir"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden items-center gap-4 md:flex">
          <a
            href="#contact"
            className="font-mono text-xs uppercase tracking-wide text-oceanic-noir/70 transition-colors duration-micro ease-out-micro hover:text-oceanic-noir"
          >
            Sign in
          </a>
          <a
            href="#contact"
            className="rounded-full bg-oceanic-noir px-4 py-2 font-mono text-xs uppercase tracking-wide text-arctic-powder transition-colors duration-micro ease-out-micro hover:bg-nocturnal-expedition"
          >
            Start building
          </a>
        </div>

        <button
          type="button"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
          aria-controls="mobile-nav"
          onClick={() => setMenuOpen((open) => !open)}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-mystic-mint md:hidden"
        >
          {menuOpen ? (
            <Icon name="x-mark" className="h-4 w-4 text-oceanic-noir" />
          ) : (
            <span className="flex flex-col gap-1.5" aria-hidden>
              <span className="block h-px w-4 bg-oceanic-noir" />
              <span className="block h-px w-4 bg-oceanic-noir" />
              <span className="block h-px w-4 bg-oceanic-noir" />
            </span>
          )}
        </button>
      </nav>

      <div
        id="mobile-nav"
        className="accordion-panel md:hidden"
        data-open={menuOpen}
      >
        <div className="accordion-panel-inner border-t border-mystic-mint/60 px-6 py-4">
          <ul className="flex flex-col gap-4">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setMenuOpen(false)}
                  className="font-mono text-sm uppercase tracking-wide text-oceanic-noir/80"
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href="#contact"
                onClick={() => setMenuOpen(false)}
                className="inline-flex rounded-full bg-oceanic-noir px-4 py-2 font-mono text-xs uppercase tracking-wide text-arctic-powder"
              >
                Start building
              </a>
            </li>
          </ul>
        </div>
      </div>
    </header>
  );
}
