import { Icon } from "@/components/ui/Icon";

const COLUMNS = [
  {
    heading: "Product",
    links: [
      { label: "Platform", href: "#platform" },
      { label: "Pricing", href: "#pricing" },
      { label: "Changelog", href: "#" },
      { label: "Status", href: "#" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "Customers", href: "#customers" },
      { label: "Careers", href: "#" },
      { label: "Contact", href: "#contact" },
    ],
  },
  {
    heading: "Resources",
    links: [
      { label: "Documentation", href: "#" },
      { label: "FAQ", href: "#faq" },
      { label: "Privacy policy", href: "#" },
      { label: "Terms of service", href: "#" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="bg-oceanic-noir px-6 pt-20 text-arctic-powder sm:px-10 lg:px-16">
      <div className="mx-auto max-w-6xl">
        <div className="grid gap-12 border-b border-arctic-powder/10 pb-16 sm:grid-cols-2 lg:grid-cols-[1.3fr_repeat(3,1fr)]">
          <div>
            <p className="font-mono text-lg font-semibold">
              relay<span className="text-forsythia">.</span>
            </p>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-arctic-powder/60">
              The control layer for AI-driven data automation. Built for teams
              who measure pipelines in milliseconds, not days.
            </p>
            <a
              href="#contact"
              className="mt-6 inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wide text-forsythia"
            >
              Talk to the team
              <Icon name="link" className="h-3.5 w-3.5" />
            </a>
          </div>

          {COLUMNS.map((column) => (
            <div key={column.heading}>
              <p className="font-mono text-xs uppercase tracking-wide text-arctic-powder/40">
                {column.heading}
              </p>
              <ul className="mt-4 flex flex-col gap-3">
                {column.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-arctic-powder/75 transition-colors duration-micro ease-out-micro hover:text-arctic-powder"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="flex flex-col items-center justify-between gap-4 py-6 sm:flex-row">
          <p className="text-xs text-arctic-powder/40">
            &copy; {new Date().getFullYear()} Relay AI. All rights reserved.
          </p>
          <p className="font-mono text-xs text-arctic-powder/40">
            Built for the Frontend Battle speed run.
          </p>
        </div>
      </div>

      <div aria-hidden className="overflow-hidden">
        <p className="select-none whitespace-nowrap text-center font-mono font-bold leading-none text-arctic-powder/[0.06]" style={{ fontSize: "min(22vw, 260px)" }}>
          relay
        </p>
      </div>
    </footer>
  );
}
