"use client";

import { useEffect, useRef, useState } from "react";
import { BENTO_FEATURES } from "@/lib/bento-data";
import { Icon } from "@/components/ui/Icon";

const MOBILE_QUERY = "(max-width: 767px)";

/**
 * Feature 2 — Bento-to-Accordion Wrapper with State Persistence
 * ----------------------------------------------------------------
 * Two presentational views (<BentoGrid> for desktop, <Accordion> for
 * mobile) are both mounted at all times; CSS alone decides which is
 * visible (`hidden md:grid` / `md:hidden`), so the correct layout paints
 * immediately on first render with no client-side flash.
 *
 * Both views read/write the *same* lifted `activeIndex` state, so there
 * is nothing to keep in sync between them — a hover on desktop and the
 * open panel on mobile are just two views of one number.
 *
 * The Context Lock Constraint — "transfer the exact active index context
 * to the mobile Accordion state when resizing past the breakpoint mid
 * interaction" — is handled explicitly below: a `matchMedia` listener
 * watches the breakpoint, and the instant it flips to mobile, whatever
 * node currently has hover/focus (`hoverIndex`) is promoted into
 * `activeIndex` before the accordion paints its open panel.
 */
export function BentoAccordion() {
  const [activeIndex, setActiveIndex] = useState<number | null>(0);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const hoverRef = useRef<number | null>(null);
  hoverRef.current = hoverIndex;

  useEffect(() => {
    const mql = window.matchMedia(MOBILE_QUERY);

    const handleBreakpointChange = (matches: boolean) => {
      if (!matches) return; // only act when *entering* the mobile range
      const liveHover = hoverRef.current;
      if (liveHover !== null) {
        // Programmatic context transfer: the node being hovered/focused
        // at the exact moment of the resize becomes the open accordion
        // panel, instead of resetting to whatever was last clicked.
        setActiveIndex(liveHover);
      }
    };

    // Run once on mount in case the page loads already under the
    // breakpoint with a context to honor (e.g. restored scroll + focus).
    handleBreakpointChange(mql.matches);

    const listener = (event: MediaQueryListEvent) => handleBreakpointChange(event.matches);
    mql.addEventListener("change", listener);
    return () => mql.removeEventListener("change", listener);
  }, []);

  return (
    <div>
      <div className="hidden md:grid md:grid-cols-3 md:gap-4 lg:gap-5">
        {BENTO_FEATURES.map((feature, index) => (
          <BentoCell
            key={feature.id}
            feature={feature}
            index={index}
            isActive={index === (hoverIndex ?? activeIndex)}
            onEnter={() => {
              setHoverIndex(index);
              setActiveIndex(index);
            }}
            onLeave={() => setHoverIndex(null)}
          />
        ))}
      </div>

      <div className="flex flex-col gap-3 md:hidden">
        {BENTO_FEATURES.map((feature, index) => (
          <AccordionItem
            key={feature.id}
            feature={feature}
            index={index}
            isOpen={index === activeIndex}
            onToggle={() => setActiveIndex(activeIndex === index ? null : index)}
          />
        ))}
      </div>
    </div>
  );
}

function BentoCell({
  feature,
  index,
  isActive,
  onEnter,
  onLeave,
}: {
  feature: (typeof BENTO_FEATURES)[number];
  index: number;
  isActive: boolean;
  onEnter: () => void;
  onLeave: () => void;
}) {
  const spanClass =
    feature.span === "wide"
      ? "col-span-2"
      : feature.span === "tall"
        ? "row-span-2"
        : "";

  return (
    <article
      tabIndex={0}
      data-index={index}
      onMouseEnter={onEnter}
      onMouseLeave={onLeave}
      onFocus={onEnter}
      onBlur={onLeave}
      className={`group flex flex-col justify-between rounded-2xl border p-6 transition-all duration-micro ease-out-micro ${spanClass} ${
        isActive
          ? "-translate-y-1 border-forsythia bg-oceanic-noir shadow-xl shadow-oceanic-noir/15"
          : "border-mystic-mint bg-white"
      }`}
    >
      <div className="flex items-start justify-between">
        <span
          className={`flex h-10 w-10 items-center justify-center rounded-full transition-colors duration-micro ease-out-micro ${
            isActive ? "bg-forsythia text-oceanic-noir" : "bg-arctic-powder text-nocturnal-expedition"
          }`}
        >
          <Icon name={feature.icon} className="h-5 w-5" />
        </span>
        {feature.metric ? (
          <span
            className={`text-right font-mono text-xs ${
              isActive ? "text-arctic-powder/70" : "text-oceanic-noir/50"
            }`}
          >
            <span className="block text-lg font-medium text-deep-saffron">
              {feature.metric.value}
            </span>
            {feature.metric.label}
          </span>
        ) : null}
      </div>

      <div className="mt-5">
        <h3
          className={`font-mono text-base font-medium transition-colors duration-micro ease-out-micro ${
            isActive ? "text-arctic-powder" : "text-oceanic-noir"
          }`}
        >
          {feature.title}
        </h3>
        <p
          className={`mt-2 text-sm leading-relaxed transition-colors duration-micro ease-out-micro ${
            isActive ? "text-arctic-powder/75" : "text-oceanic-noir/65"
          }`}
        >
          {feature.description}
        </p>
      </div>
    </article>
  );
}

function AccordionItem({
  feature,
  index,
  isOpen,
  onToggle,
}: {
  feature: (typeof BENTO_FEATURES)[number];
  index: number;
  isOpen: boolean;
  onToggle: () => void;
}) {
  const panelId = `bento-accordion-panel-${feature.id}`;
  const headerId = `bento-accordion-header-${feature.id}`;

  return (
    <div
      data-index={index}
      className={`rounded-2xl border transition-colors duration-micro ease-out-micro ${
        isOpen ? "border-forsythia bg-oceanic-noir" : "border-mystic-mint bg-white"
      }`}
    >
      <h3 className="m-0">
        <button
          type="button"
          id={headerId}
          aria-expanded={isOpen}
          aria-controls={panelId}
          onClick={onToggle}
          className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left"
        >
          <span className="flex items-center gap-3">
            <span
              className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                isOpen ? "bg-forsythia text-oceanic-noir" : "bg-arctic-powder text-nocturnal-expedition"
              }`}
            >
              <Icon name={feature.icon} className="h-4 w-4" />
            </span>
            <span
              className={`font-mono text-sm font-medium ${
                isOpen ? "text-arctic-powder" : "text-oceanic-noir"
              }`}
            >
              {feature.title}
            </span>
          </span>
          <Icon
            name="chevron-down"
            className={`h-4 w-4 shrink-0 transition-transform duration-micro ease-out-micro ${
              isOpen ? "rotate-180 text-forsythia" : "text-oceanic-noir/50"
            }`}
          />
        </button>
      </h3>
      <div
        id={panelId}
        role="region"
        aria-labelledby={headerId}
        className="accordion-panel"
        data-open={isOpen}
      >
        <div className="accordion-panel-inner px-5 pb-4">
          <p className={`text-sm leading-relaxed ${isOpen ? "text-arctic-powder/75" : "text-oceanic-noir/65"}`}>
            {feature.description}
          </p>
        </div>
      </div>
    </div>
  );
}
