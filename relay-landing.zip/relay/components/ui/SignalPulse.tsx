/**
 * The page's signature motif: a single traveling signal line, echoing the
 * "relay" idea of a pulse moving through a network. Pure inline SVG with
 * a CSS `stroke-dashoffset` animation — no canvas, no animation library.
 */
export function SignalPulse({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 600 120"
      fill="none"
      aria-hidden
      className={className}
      preserveAspectRatio="none"
    >
      <path
        d="M0 60 H140 L165 20 L195 100 L220 60 H300 L325 35 L350 85 L375 60 H600"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray="6 10"
        className="animate-pulse-line"
        opacity="0.55"
      />
    </svg>
  );
}
