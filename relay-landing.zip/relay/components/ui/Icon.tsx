type IconName =
  | "link"
  | "link-solid"
  | "x-mark"
  | "chevron-down"
  | "chevron-up"
  | "chevron-up-solid"
  | "chevron-left"
  | "chevron-right"
  | "cog-8-tooth"
  | "chart-pie"
  | "cube-16-solid"
  | "search"
  | "arrow-path"
  | "arrow-trending-up";

interface IconProps {
  name: IconName;
  className?: string;
  label?: string;
}

/**
 * Renders one of the provided SVG-pack icons.
 *
 * The source files are single-color outline/solid glyphs. Rather than
 * inlining (and forking) the markup, we apply them as a CSS mask so they
 * inherit `currentColor` and can be recolored per-context with normal
 * utility classes — no external icon library required.
 */
export function Icon({ name, className = "h-5 w-5", label }: IconProps) {
  return (
    <span
      role={label ? "img" : "presentation"}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      className={`icon-mask ${className}`}
      style={{
        WebkitMaskImage: `url(/icons/${name}.svg)`,
        maskImage: `url(/icons/${name}.svg)`,
      }}
    />
  );
}
