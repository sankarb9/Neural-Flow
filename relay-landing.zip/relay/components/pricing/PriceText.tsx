"use client";

import { useEffect, useRef } from "react";
import { computePrice, PricingTier } from "@/lib/pricing-data";
import { pricingStore } from "@/lib/pricing-store";

interface PriceTextProps {
  tier: PricingTier;
  /** Render the trailing "/mo" style suffix as a separate, static node. */
  className?: string;
}

/**
 * The single DOM node that ever changes when currency/billing flips.
 *
 * Server-rendered with the default (USD / monthly) price so it's a real,
 * crawlable text node on first paint — important for both SEO and for
 * avoiding a flash of empty content. After mount, it subscribes to the
 * pricing store and updates `textContent` imperatively. React never
 * re-renders this component (or anything above it) after the initial
 * paint; only this span's text node mutates.
 */
export function PriceText({ tier, className }: PriceTextProps) {
  const spanRef = useRef<HTMLSpanElement>(null);
  const initial = computePrice(tier, pricingStore.getState().billing, pricingStore.getState().currency);

  useEffect(() => {
    const render = () => {
      const { billing, currency } = pricingStore.getState();
      const { symbol, formatted } = computePrice(tier, billing, currency);
      const node = spanRef.current;
      if (node) {
        node.textContent = `${symbol}${formatted}`;
      }
    };

    // Sync immediately in case the store changed between server render
    // and hydration (e.g. a fast click during streaming).
    render();
    return pricingStore.subscribe(render);
  }, [tier]);

  return (
    <span
      ref={spanRef}
      className={className}
      data-tier={tier.id}
      aria-live="polite"
      suppressHydrationWarning
    >
      {initial.symbol}
      {initial.formatted}
    </span>
  );
}
