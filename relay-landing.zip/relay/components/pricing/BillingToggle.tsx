"use client";

import { useId, useRef, useState } from "react";
import { ANNUAL_SAVINGS_PERCENT, BillingCycle } from "@/lib/pricing-data";
import { pricingStore } from "@/lib/pricing-store";

const OPTIONS: { id: BillingCycle; label: string }[] = [
  { id: "monthly", label: "Monthly" },
  { id: "annual", label: "Annual" },
];

/**
 * Controls billing cadence. Owns only its own selected-pill visual state;
 * the actual price values live downstream in <PriceText>, which reads the
 * pricing store directly. Selecting a pill here never touches that tree.
 */
export function BillingToggle() {
  const [selected, setSelected] = useState<BillingCycle>(pricingStore.getState().billing);
  const groupId = useId();
  const refs = useRef<Record<string, HTMLButtonElement | null>>({});

  function select(id: BillingCycle) {
    setSelected(id);
    pricingStore.setBilling(id);
  }

  const activeIndex = OPTIONS.findIndex((o) => o.id === selected);

  return (
    <div className="inline-flex items-center gap-3">
      <div
        role="radiogroup"
        aria-label="Billing cycle"
        className="relative inline-flex rounded-full border border-nocturnal-expedition/15 bg-white p-1"
      >
        <span
          aria-hidden
          className="absolute inset-y-1 left-1 rounded-full bg-oceanic-noir transition-transform duration-micro ease-out-micro"
          style={{
            width: `calc(${100 / OPTIONS.length}% - 4px)`,
            transform: `translateX(calc(${activeIndex * 100}% + ${activeIndex * 4}px))`,
          }}
        />
        {OPTIONS.map((option) => {
          const isActive = option.id === selected;
          return (
            <button
              key={option.id}
              ref={(el) => {
                refs.current[option.id] = el;
              }}
              type="button"
              role="radio"
              aria-checked={isActive}
              id={`${groupId}-${option.id}`}
              onClick={() => select(option.id)}
              className={`relative z-10 rounded-full px-4 py-1.5 font-mono text-xs uppercase tracking-wide transition-colors duration-micro ease-out-micro ${
                isActive ? "text-arctic-powder" : "text-oceanic-noir/70 hover:text-oceanic-noir"
              }`}
            >
              {option.label}
            </button>
          );
        })}
      </div>
      <span
        className={`font-mono text-xs uppercase tracking-wide text-nocturnal-expedition transition-opacity duration-micro ease-out-micro ${
          selected === "annual" ? "opacity-100" : "opacity-0"
        }`}
        aria-hidden={selected !== "annual"}
      >
        Save {ANNUAL_SAVINGS_PERCENT}%
      </span>
    </div>
  );
}
