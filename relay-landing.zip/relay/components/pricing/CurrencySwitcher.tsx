"use client";

import { useState } from "react";
import { Currency, CURRENCIES, REGIONAL_MATRIX } from "@/lib/pricing-data";
import { pricingStore } from "@/lib/pricing-store";

/**
 * The "Performance-Isolated Currency Switcher". Like <BillingToggle>, this
 * owns only its own selected-pill state — selecting a currency dispatches
 * to the pricing store and stops there. It never touches the pricing
 * cards, which read the store independently via <PriceText>.
 */
export function CurrencySwitcher() {
  const [selected, setSelected] = useState<Currency>(pricingStore.getState().currency);

  function select(currency: Currency) {
    setSelected(currency);
    pricingStore.setCurrency(currency);
  }

  const activeIndex = CURRENCIES.indexOf(selected);

  return (
    <div
      role="radiogroup"
      aria-label="Display currency"
      className="relative inline-flex rounded-full border border-nocturnal-expedition/15 bg-white p-1"
    >
      <span
        aria-hidden
        className="absolute inset-y-1 left-1 rounded-full bg-forsythia transition-transform duration-micro ease-out-micro"
        style={{
          width: `calc(${100 / CURRENCIES.length}% - 4px)`,
          transform: `translateX(calc(${activeIndex * 100}% + ${activeIndex * 4}px))`,
        }}
      />
      {CURRENCIES.map((currency) => {
        const isActive = currency === selected;
        return (
          <button
            key={currency}
            type="button"
            role="radio"
            aria-checked={isActive}
            onClick={() => select(currency)}
            className={`relative z-10 rounded-full px-3.5 py-1.5 font-mono text-xs tracking-wide transition-colors duration-micro ease-out-micro ${
              isActive ? "text-oceanic-noir" : "text-oceanic-noir/60 hover:text-oceanic-noir"
            }`}
          >
            {REGIONAL_MATRIX[currency].symbol} {currency}
          </button>
        );
      })}
    </div>
  );
}
