/**
 * Feature 1 — Matrix-Driven Pricing
 * ----------------------------------
 * Every displayed price is *derived* at read-time from this configuration
 * matrix. Nothing in the UI layer hardcodes a final price — components
 * only ever call `computePrice()`.
 *
 * Dimensions:
 *   tier      -> base monthly rate (USD canonical)
 *   billing   -> flat 20% annual discount multiplier
 *   currency  -> FX rate + regional tariff load factor
 */

export type Currency = "INR" | "USD" | "EUR";
export type BillingCycle = "monthly" | "annual";

export interface PricingTier {
  id: string;
  name: string;
  eyebrow: string;
  baseRateUSD: number;
  description: string;
  features: string[];
  highlighted?: boolean;
}

export interface RegionalConfig {
  symbol: string;
  /** USD -> currency FX conversion factor. */
  fxRate: number;
  /**
   * Regional tariff variable — accounts for local payment processing,
   * compliance, and infrastructure-hosting load by region.
   */
  tariff: number;
  locale: string;
}

/** Flat annual-billing discount multiplier (20% off). */
export const ANNUAL_DISCOUNT_MULTIPLIER = 0.8;

export const REGIONAL_MATRIX: Record<Currency, RegionalConfig> = {
  USD: { symbol: "$", fxRate: 1, tariff: 1.0, locale: "en-US" },
  EUR: { symbol: "\u20AC", fxRate: 0.93, tariff: 1.06, locale: "de-DE" },
  INR: { symbol: "\u20B9", fxRate: 83.4, tariff: 1.18, locale: "en-IN" },
};

export const PRICING_TIERS: PricingTier[] = [
  {
    id: "signal",
    name: "Signal",
    eyebrow: "For small teams",
    baseRateUSD: 29,
    description: "Get a single workflow live and see automated data move end to end.",
    features: [
      "3 automated pipelines",
      "50K events / month",
      "Community support",
      "Single workspace",
    ],
  },
  {
    id: "relay",
    name: "Relay",
    eyebrow: "For growing teams",
    baseRateUSD: 99,
    description: "Scale pipelines across a team without scaling your headcount.",
    features: [
      "Unlimited pipelines",
      "2M events / month",
      "Priority support",
      "Role-based access",
      "Audit logging",
    ],
    highlighted: true,
  },
  {
    id: "mainline",
    name: "Mainline",
    eyebrow: "For platform teams",
    baseRateUSD: 249,
    description: "Run mission-critical data infrastructure with dedicated guarantees.",
    features: [
      "Unlimited everything",
      "Dedicated throughput SLA",
      "24/7 named support",
      "SSO / SAML",
      "Private deployment region",
    ],
  },
];

export interface ComputedPrice {
  amount: number;
  symbol: string;
  formatted: string;
}

/**
 * Resolves a final display price for a given tier, billing cycle, and
 * currency by walking the configuration matrix above. No magic numbers —
 * every factor is named and sourced from the matrix.
 */
export function computePrice(
  tier: PricingTier,
  billing: BillingCycle,
  currency: Currency
): ComputedPrice {
  const region = REGIONAL_MATRIX[currency];
  const cycleMultiplier = billing === "annual" ? ANNUAL_DISCOUNT_MULTIPLIER : 1;

  const rawMonthlyEquivalent = tier.baseRateUSD * region.fxRate * region.tariff * cycleMultiplier;

  // INR/JPY-style currencies read cleaner with no decimal places; others
  // round to whole units too, since these are marketing-facing prices.
  const amount = Math.round(rawMonthlyEquivalent);

  const formatted = new Intl.NumberFormat(region.locale, {
    maximumFractionDigits: 0,
  }).format(amount);

  return { amount, symbol: region.symbol, formatted };
}

export const ANNUAL_SAVINGS_PERCENT = Math.round((1 - ANNUAL_DISCOUNT_MULTIPLIER) * 100);

export const CURRENCIES: Currency[] = ["USD", "EUR", "INR"];
