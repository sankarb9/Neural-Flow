export const siteConfig = {
  name: "Relay",
  title: "Relay — Automate the data your AI agents depend on",
  description:
    "Relay is the AI-driven data automation platform that connects every source system into one pipeline layer — with matrix-driven, multi-currency pricing and a runtime built for production-grade workflows.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "https://relay-demo.vercel.app",
  ogImage: "/opengraph-image",
  keywords: [
    "AI data automation",
    "data pipeline platform",
    "workflow automation",
    "AI agents infrastructure",
    "data integration platform",
  ],
};

export type SiteConfig = typeof siteConfig;
