import { Icon } from "@/components/ui/Icon";

export type IconName = Parameters<typeof Icon>[0]["name"];

export interface BentoFeature {
  id: string;
  title: string;
  description: string;
  icon: IconName;
  /** Desktop bento cells use this to vary the grid rhythm. */
  span?: "wide" | "tall" | "default";
  metric?: { value: string; label: string };
}

export const BENTO_FEATURES: BentoFeature[] = [
  {
    id: "realtime-sync",
    title: "Realtime sync",
    description:
      "Every pipeline replicates state across sources in milliseconds, so dashboards and downstream agents never read stale data.",
    icon: "arrow-path",
    span: "wide",
    metric: { value: "12ms", label: "median sync lag" },
  },
  {
    id: "adaptive-routing",
    title: "Adaptive routing",
    description:
      "Workloads reroute around failed nodes automatically, with no manual failover step.",
    icon: "arrow-trending-up",
    span: "default",
  },
  {
    id: "unified-schema",
    title: "Unified schema",
    description:
      "One typed schema layer reconciles every source system, so a field renamed upstream never silently breaks a pipeline.",
    icon: "cube-16-solid",
    span: "tall",
  },
  {
    id: "insight-engine",
    title: "Insight engine",
    description:
      "Built-in analytics surface drift, anomalies, and throughput trends without exporting to a separate BI tool.",
    icon: "chart-pie",
    span: "default",
  },
  {
    id: "secure-mesh",
    title: "Secure mesh",
    description:
      "Every hop is encrypted in transit and at rest, with access scoped down to the individual pipeline.",
    icon: "cog-8-tooth",
    span: "default",
  },
  {
    id: "open-integrations",
    title: "Open integrations",
    description:
      "Connect warehouses, queues, and internal APIs with the same interface — no proprietary connector tax.",
    icon: "link-solid",
    span: "wide",
  },
];
