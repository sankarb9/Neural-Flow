import { BillingCycle, Currency } from "./pricing-data";

export interface PricingState {
  currency: Currency;
  billing: BillingCycle;
}

type Listener = (state: PricingState) => void;

/**
 * A deliberately tiny pub-sub store — not Context, not a state library.
 *
 * Why: the brief's "Re-render & State Isolation Guardrail" requires that
 * flipping currency/billing never re-renders the pricing section, the
 * page, or sibling cards — only the specific text nodes holding a price.
 *
 * If this lived in React state/Context, *any* component reading it would
 * re-render on every change (even with memoization you're trusting the
 * reconciler, not guaranteeing zero work). Instead, `PriceText` leaf
 * components (see components/pricing/PriceText.tsx) subscribe directly
 * to this store and mutate their own DOM text node in the subscription
 * callback — completely outside of React's render cycle. Toggling a
 * currency or billing cycle therefore produces zero React commits.
 */
class PricingStore {
  private state: PricingState = { currency: "USD", billing: "monthly" };
  private listeners = new Set<Listener>();

  getState(): PricingState {
    return this.state;
  }

  setCurrency(currency: Currency) {
    if (currency === this.state.currency) return;
    this.state = { ...this.state, currency };
    this.emit();
  }

  setBilling(billing: BillingCycle) {
    if (billing === this.state.billing) return;
    this.state = { ...this.state, billing };
    this.emit();
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private emit() {
    for (const listener of this.listeners) listener(this.state);
  }
}

export const pricingStore = new PricingStore();
