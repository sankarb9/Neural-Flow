import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Provided brand palette — named per the asset spec sheet.
        "arctic-powder": "#F1F6F4",
        forsythia: "#FFC801",
        "nocturnal-expedition": "#114C5A",
        "mystic-mint": "#D9E8E2",
        "deep-saffron": "#FF9932",
        "oceanic-noir": "#172B36",
      },
      fontFamily: {
        mono: ["var(--font-jetbrains-mono)", "ui-monospace", "monospace"],
        sans: ["var(--font-inter)", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      transitionDuration: {
        "micro-min": "150ms",
        micro: "180ms",
        "micro-max": "200ms",
        "reflow-min": "300ms",
        reflow: "350ms",
        "reflow-max": "400ms",
      },
      transitionTimingFunction: {
        "out-micro": "cubic-bezier(0.16, 1, 0.3, 1)",
        "inout-reflow": "cubic-bezier(0.65, 0, 0.35, 1)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(14px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "fade-in": {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        "pulse-line": {
          "0%": { strokeDashoffset: "240" },
          "100%": { strokeDashoffset: "0" },
        },
        shimmer: {
          "0%": { backgroundPosition: "200% 0" },
          "100%": { backgroundPosition: "-200% 0" },
        },
      },
      animation: {
        "fade-up": "fade-up 500ms cubic-bezier(0.16,1,0.3,1) both",
        "fade-in": "fade-in 400ms cubic-bezier(0.16,1,0.3,1) both",
        "pulse-line": "pulse-line 2.4s linear infinite",
        shimmer: "shimmer 3s linear infinite",
      },
    },
  },
  plugins: [],
};

export default config;
